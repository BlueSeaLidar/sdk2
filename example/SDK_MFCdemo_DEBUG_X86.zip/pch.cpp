﻿// pch.cpp: 与预编译标头对应的源文件
#pragma warning(disable:4996)

#include "pch.h"

// 当使用预编译的头时，需要使用此源文件，编译才能成功。
