﻿
// demo2Dlg.cpp: 实现文件
/*************************************************主要说明*********************************************************/
// 工程配置：
//C/C++->常规->附加包含目录中的文件路径
//C/C++->常规->SDL检查  关闭
//C/C++->预编译头 预编译头 关闭
/*************************************************主要说明*********************************************************/
#pragma warning(disable:4996)

#include "pch.h"
#include "framework.h"
#include "demo2.h"
#include "demo2Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// Cdemo2Dlg 对话框



Cdemo2Dlg::Cdemo2Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DEMO2_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void Cdemo2Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST2, m_list);
}

BEGIN_MESSAGE_MAP(Cdemo2Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, &Cdemo2Dlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &Cdemo2Dlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &Cdemo2Dlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &Cdemo2Dlg::OnBnClickedButton4)
//	ON_WM_ACTIVATE()
ON_WM_TIMER()
END_MESSAGE_MAP()


// Cdemo2Dlg 消息处理程序

BOOL Cdemo2Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码

	DWORD dwstyle = m_list.GetExtendedStyle();
	dwstyle |= LVS_EX_FULLROWSELECT;
	dwstyle |= LVS_EX_GRIDLINES;
	m_list.SetExtendedStyle(dwstyle);

	m_list.InsertColumn(0, "IP/UART", LVA_ALIGNLEFT, 160);
	m_list.InsertColumn(1, "port/baud", LVA_ALIGNLEFT, 80);
	m_list.InsertColumn(2, "num", LVA_ALIGNLEFT, 60);
	m_list.InsertColumn(3, "timestamp", LVA_ALIGNLEFT, 200);

	SetTimer(1, 100, NULL);

	

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void Cdemo2Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void Cdemo2Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR Cdemo2Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


/********************************************************************************调整代码**************************************************/

CArray<PointData, PointData&> m_datas;
void CallBackMsg(int msgtype, void* param)
{
	//实时雷达数据返回
	if (msgtype == 1)
	{
		PointData* pointdata = (PointData*)param;
		for (int i = 0; i < pointdata->N; i++)
		{
			printf("%s\t%d \t %d\t%.5f\t%.3f\t%d\n", pointdata->ip,pointdata->port, pointdata->N,pointdata->points[i].angle, pointdata->points[i].distance, pointdata->points[i].confidence);
		}
		//PointData* tmp = new PointData;
		//memcpy(tmp, param, sizeof(PointData));
		m_datas.Add(*pointdata);
	}
	//实时防区数据返回
	else if (msgtype == 2)
	{
		LidarMsgHdr* zone = (LidarMsgHdr*)param;
		uint32_t event = zone->events;
		std::string text;
		if (zone->flags % 2 == 1) {
			//错误信息
			if (getbit(event, 0) == 1) {
				text += "供电不足";
			}
			if (getbit(event, 1) == 1) {
				text += "电机堵转足";
			}
			if (getbit(event, 2) == 1) {
				text += "测距模块温度过高";
			}
			if (getbit(event, 3) == 1) {
				text += "网络错误";
			}
			if (getbit(event, 4) == 1) {
				text += "测距模块无输出";
			}
			if (getbit(event, 5) == 1) {
				text += "角度异常";
			}
			if (getbit(event, 6) == 1) {
				text += "测距数据异常";
			}
		}
		if (zone->flags >= 0x100) {
			//防区信息
			if (getbit(event, 12) == 1) {
				text += "观察！！！";
			}
			if (getbit(event, 13) == 1) {
				text += "警戒！！！";
			}
			if (getbit(event, 14) == 1) {
				text += "报警！！！";
			}
			if (getbit(event, 15) == 1) {
				text += "遮挡！";
			}
			if (getbit(event, 16) == 1) {
				text += "无数据";
			}
			if (getbit(event, 17) == 1) {
				text += "无防区设置";
			}
			if (getbit(event, 18) == 1) {
				text += "系统内部错误";
			}
			if (getbit(event, 19) == 1) {
				text += "系统运行异常";
			}
			if (getbit(event, 20) == 1) {
				//和上面的第四项重复，这里屏蔽
				//text+='网络错误\n'
			}
			if (getbit(event, 21) == 1) {
				text += "设备更新中";
			}
			if (getbit(event, 22) == 1) {
				text += "零位输出";
			}
		}
		printf("Active zone:%d\tMSG:%s\n", zone->zone_actived, text.c_str());
	}
	//获取错误信息
	else if (msgtype == 3)
	{
		char* result = (char*)param;
		printf("Error Info : %s\n", result);

	}
	//获取雷达时间戳打印信息
	else if (msgtype == 4)
	{
		DevTimestamp* devtimestamp = (DevTimestamp*)param;
		printf("timestamp:lidar_ip:%s lidar_port:%d time:%d delay:%d\n", devtimestamp->ip, devtimestamp->port, devtimestamp->timestamp, devtimestamp->delay);
	}
}

//打印
void PrintMsg(int msgtype, void* param)
{

	//获取硬件设备的配信息   当前串口版本仅返回序列号，其他信息为空
	if (msgtype == 2)
	{
		EEpromV101* eepromv101 = (EEpromV101*)param;
		//类型，编号，序列号
		char tmp_sn[20] = { 0 };
		memcpy(tmp_sn, eepromv101->dev_sn, sizeof(eepromv101->dev_sn) - 1);
		char tmp_type[16] = { 0 };
		memcpy(tmp_type, eepromv101->dev_type, sizeof(eepromv101->dev_type) - 1);

		INFO_PR("dev info: 设备编号:%d\t 序列号:%s\t 类型:%s\n", eepromv101->dev_id, tmp_sn, tmp_type);
		// ip地址 子网掩码 网关地址 默认目标IP  默认目标udp端口号  默认UDP对外服务端口号
		char tmp_IPv4[16] = { 0 };
		char tmp_mask[16] = { 0 };
		char tmp_gateway[16] = { 0 };
		char tmp_srv_ip[16] = { 0 };

		sprintf(tmp_IPv4, "%d.%d.%d.%d", eepromv101->IPv4[0], eepromv101->IPv4[1], eepromv101->IPv4[2], eepromv101->IPv4[3]);
		sprintf(tmp_mask, "%d.%d.%d.%d", eepromv101->mask[0], eepromv101->mask[1], eepromv101->mask[2], eepromv101->mask[3]);
		sprintf(tmp_gateway, "%d.%d.%d.%d", eepromv101->gateway[0], eepromv101->gateway[1], eepromv101->gateway[2], eepromv101->gateway[3]);
		sprintf(tmp_srv_ip, "%d.%d.%d.%d", eepromv101->srv_ip[0], eepromv101->srv_ip[1], eepromv101->srv_ip[2], eepromv101->srv_ip[3]);

		INFO_PR("dev info: ip地址:%s 子网掩码:%s 网关地址:%s 默认目标IP:%s  默认目标udp端口号:%d   默认UDP对外服务端口号:%d\n",
			tmp_IPv4, tmp_mask, tmp_gateway, tmp_srv_ip, eepromv101->srv_port, eepromv101->local_port);

		/*char tmp_ranger_bias[8] = {0};
		memcpy(tmp_ranger_bias, eepromv101->ranger_bias, sizeof(eepromv101->ranger_bias) - 1);*/
		//转速 ,电机启动参数,FIR滤波阶数，圈数，分辨率，开机自动上传，固定上传，数据点平滑，去拖点，记录校正系数，网络心跳，记录IO口极性
		INFO_PR("dev info: 转速:%d 电机启动参数:%d FIR滤波阶数:%d 圈数:%d  分辨率:%d   开机自动上传:%d 固定上传:%d  数据点平滑:%d 去拖点:%d   网络心跳:%d  记录IO口极性:%d\n",
			eepromv101->RPM, eepromv101->RPM_pulse, eepromv101->fir_filter, eepromv101->cir, eepromv101->with_resample, eepromv101->auto_start,
			eepromv101->target_fixed, eepromv101->with_smooth, eepromv101->with_filter, eepromv101->net_watchdog, eepromv101->pnp_flags);

		INFO_PR("dev info:平滑系数：%d  激活防区：%d  上传数据类型：%d", eepromv101->deshadow, eepromv101->zone_acted, eepromv101->should_post);
	}
	//设置硬件配置数据，如果成功，则打印OK    S_PACK
	else if (msgtype == 3)
	{
		DevData* devdata = (DevData*)param;
		for (int i = 0; i < sizeof(devdata->set) - 1; i++)
		{
			char buf[3] = { 0 };
			if (devdata->set[i] == '1')
			{
				memcpy(buf, devdata->result + 2 * i, 2);
				INFO_PR("DEV SET  index:%d  result:%s\n", i, buf);
			}
		}
	}
	fflush(stdout);
}





void Cdemo2Dlg::OnBnClickedButton1()
{
	// TODO: 在此添加控件通知处理程序代码
	CString cfg_file_name = "LSS-40D-C30E.txt";
	m_cfg =new RunConfig;
	m_cfg->callback = CallBackMsg;
	if (!read_config(cfg_file_name, *m_cfg))
	{
		CString error = "config file is not exist " + cfg_file_name;
		MessageBox(error);
		return ;
	}

	//启动雷达设备 返回值非0表示失败  0表示可以正常接收包数据
	int res = openDev(*m_cfg, 0);
	if (res != 0)
	{
		CString error = "open dev failed";
		MessageBox(error);
		return;
	}
	getLidarData(m_cfg->thread_ID[1], true);
}


void Cdemo2Dlg::OnBnClickedButton2()
{
	// TODO: 在此添加控件通知处理程序代码

	ControlDrv(m_cfg->thread_ID[1], "LSTARH");
	
}


void Cdemo2Dlg::OnBnClickedButton3()
{
	// TODO: 在此添加控件通知处理程序代码
	ControlDrv(m_cfg->thread_ID[1], "LSTOPH");
}


void Cdemo2Dlg::OnBnClickedButton4()
{
	// TODO: 在此添加控件通知处理程序代码
	ControlDrv(m_cfg->thread_ID[1], "LRESTH");
}



void Cdemo2Dlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值

	CDialogEx::OnTimer(nIDEvent);

	if (m_list.GetItemCount() > 100)
	{
		for (int i = 0; i < m_list.GetItemCount() - 100; i++)
		{
			m_list.DeleteItem(i);
		}
	}
	int num = m_list.GetItemCount();
	//if (m_datas.GetSize() < 100)
	{
		for (int i = 0; i < m_datas.GetSize(); i++)
		{
			PointData data = m_datas.GetAt(i);

			CString port;
			port.Format("%d", data.port);

			CString N;
			N.Format("%d", data.N);

			CString ts;
			ts.Format("%d %d", data.ts[0], data.ts[1]);
		
			m_list.InsertItem(i+ num, _T(""));
			m_list.SetItemText(i+ num, 0, data.ip);
			m_list.SetItemText(i+ num, 1, port);
			m_list.SetItemText(i+ num, 2, N);
			m_list.SetItemText(i+ num, 3, ts);
			//如果要获取全部点云数据，参考如下遍历
			/*for(int j=0;j<data.N;j++)
			{
				float angle =data.points[i].angle;
				int confidence = data.points[i].confidence;
				float distance = data.points[i].distance;
			}*/
		}
		m_datas.RemoveAll();
	}
}


