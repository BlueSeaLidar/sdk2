#pragma once
class work
{
};

